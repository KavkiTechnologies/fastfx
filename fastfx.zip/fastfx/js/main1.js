// --------------------------Prefund Balance Api Intergration-------------------------------------------
fetch('https://api.fastfx2.com/admin/totalbalance')
    .then(response => {
        if (!response.ok) {
            throw new Error("HTTP error " + response.status);
        }
        return response.text();
    })
    .then(text => {
        document.getElementById("pre").innerHTML = text;
    })
    .catch(error => {
        // Handle/report error
    });

// --------------------------Successful Transaction Api Intergration-------------------------------------------

fetch('https://api.fastfx2.com/admin/successtrans')
    .then(response => {
        if (!response.ok) {
            throw new Error("HTTP error " + response.status);
        }
        return response.text();
    })
    .then(text => {
        document.getElementById("succ").innerHTML = text;
    })
    .catch(error => {
        // Handle/report error
    });

// --------------------------Pending Transaction Api Intergration-------------------------------------------

fetch('https://api.fastfx2.com/admin/pendingtrans')
    .then(response => {
        if (!response.ok) {
            throw new Error("HTTP error " + response.status);
        }
        return response.text();
    })
    .then(text => {
        document.getElementById("pend").innerHTML = text;
    })
    .catch(error => {
        // Handle/report error
    });

// -------------------------Failed Transaction Api Intergration-------------------------------------------

fetch('https://api.fastfx2.com/admin/failedtrans')
    .then(response => {
        if (!response.ok) {
            throw new Error("HTTP error " + response.status);
        }
        return response.text();
    })
    .then(text => {
        document.getElementById("fail").innerHTML = text;
    })
    .catch(error => {
        // Handle/report error
    });
    // -------------------------Failed Transaction Api Intergration-------------------------------------------

fetch('https://api.fastfx2.com/recharge/checkbalance')
.then(response => {
    if (!response.ok) {
        throw new Error("HTTP error " + response.status);
    }
    return response.text();
})
.then(text => {
    document.getElementById("merchantview").innerHTML = text;
})
.catch(error => {
    // Handle/report error
});