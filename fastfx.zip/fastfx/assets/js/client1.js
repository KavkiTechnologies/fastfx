  //-------------------------Client prefund approval-------------------------------//
    
   
  function onApprove() 
  {
    let retailerId = 'FFR001';
    let reference = 'indian258';
    let status ='accept';
    let data = {retailerId,reference,status};
    console.log(JSON.stringify(data));
   
    fetch('http://fastfxbackend-env.eba-ihyda3cq.ap-southeast-1.elasticbeanstalk.com/client/updatebalance', {
      method: 'POST',
      headers:
      {
        'Content-Type': 'application/json'
      },
      mode: 'cors',
      body: JSON.stringify(data)
    })
    document.getElementById("acc").innerHTML = "Accepted";
  }

     
  function onApprove1() 
  {
    let retailerId = 'FFR001';
    let reference = 'indian25821';
    let status ='decline';
    let data = {retailerId,reference,status};
    console.log(JSON.stringify(data));
   
    fetch('http://fastfxbackend-env.eba-ihyda3cq.ap-southeast-1.elasticbeanstalk.com/client/updatebalance', {
      method: 'POST',
      headers:
      {
        'Content-Type': 'application/json'
      },
      mode: 'cors',
      body: JSON.stringify(data)
    })
    document.getElementById("rej").innerHTML = "Rejected";
  }