//-------------------------Client Wallet-------------------------------//
fetch('http://fastfxbackend-env.eba-ihyda3cq.ap-southeast-1.elasticbeanstalk.com/client/fastxbalance/FFX001')
    .then(response => {
        if (!response.ok) {
            throw new Error("HTTP error " + response.status);
        }
        return response.text();
    })
    .then(text => {
        document.getElementById("cwallet").innerHTML = text;
    })
    .catch(error => {
        // Handle/report error
    });