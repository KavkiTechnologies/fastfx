//-------------------------Retailer Wallet-------------------------------//
fetch('https://ebs.fastfx2.com/retailer/fastxbalance/FFR001')
    .then(response => {
        if (!response.ok) {
            throw new Error("HTTP error " + response.status);
        }
        return response.text();
    })
    .then(text => {
        document.getElementById("rwallet").innerHTML = text;
    })
    .catch(error => {
        // Handle/report error
    });
