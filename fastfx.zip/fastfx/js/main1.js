
fetch('http://fastfxbackend-env.eba-ihyda3cq.ap-southeast-1.elasticbeanstalk.com/admin/totalbalance')
.then(response => {
    if (!response.ok) {
        throw new Error("HTTP error " + response.status);
    }
    return response.text();
})
.then(text => {
    document.getElementById("pre").innerHTML = text;
})
.catch(error => {
    // Handle/report error
});


fetch('http://fastfxbackend-env.eba-ihyda3cq.ap-southeast-1.elasticbeanstalk.com/admin/successtrans')
.then(response => {
    if (!response.ok) {
        throw new Error("HTTP error " + response.status);
    }
    return response.text();
})
.then(text => {
    document.getElementById("succ").innerHTML = text;
})
.catch(error => {
    // Handle/report error
});



fetch('http://fastfxbackend-env.eba-ihyda3cq.ap-southeast-1.elasticbeanstalk.com/admin/pendingtrans')
.then(response => {
    if (!response.ok) {
        throw new Error("HTTP error " + response.status);
    }
    return response.text();
})
.then(text => {
    document.getElementById("pend").innerHTML = text;
})
.catch(error => {
    // Handle/report error
});

fetch('http://fastfxbackend-env.eba-ihyda3cq.ap-southeast-1.elasticbeanstalk.com/admin/failedtrans')
.then(response => {
    if (!response.ok) {
        throw new Error("HTTP error " + response.status);
    }
    return response.text();
})
.then(text => {
    document.getElementById("fail").innerHTML = text;
})
.catch(error => {
    // Handle/report error
});