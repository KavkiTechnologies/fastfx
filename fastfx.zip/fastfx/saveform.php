<?php

if($_POST['phone']!='' && $_POST['amount ']!='' )

if(file_exists('D:\xampp\htdocs\fastfx\json\prepaid.json'))
{

{
	$current_data= file_get_contents('D:\xampp\htdocs\fastfx\json\prepaid.json');
	$array_data=json_decode($current_data,true)  ;    
    $new_data=array(
		'phone'=>$_POST['phone'],
		'amount'=>$_POST['amount'],
	);
	$array_data[]=$new_data;
	$json_data=json_encode($array_data,JSON_PRETTY_PRINT);

	if(file_get_contents('D:\xampp\htdocs\fastfx\json\prepaid.json',$json_data))
	{
		echo"<h3>SUCCESSFUL</h3>";
	}
	else
	{
		echo"<h3>UNSUCCESSFUL</h3>";
	}
}
else
{
	echo"<h3>UNSUCCESSFUL</h3>";
}
else
	{
		echo"<h3>UNSUCCESSFUL</h3>";
	}
}
?>
