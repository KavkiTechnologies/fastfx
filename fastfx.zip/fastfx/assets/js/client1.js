  //-------------------------Client prefund approval-------------------------------//
    
  
    function onApprove(){
      var result;
  
      fetch('http://fastfxbackend-env.eba-ihyda3cq.ap-southeast-1.elasticbeanstalk.com/client/updatebalance').then(function(response) {
          result = response;
          // return response; // <- I tried that one as well
      });
  
      return result; // It always returns `undefined`
  }