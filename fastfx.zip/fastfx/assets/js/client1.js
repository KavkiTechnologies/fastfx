   
  function onApprove() 
  {
    let retailerId = 'FFR001';
    let reference = 'ubi789';
    let status ='accept';
    let data = {retailerId,reference,status};
    console.log(JSON.stringify(data));
   
    fetch('https://ebs.fastfx2.com/client/updatebalance', {
      method: 'POST',
      headers:
      {
        'Content-Type': 'application/json'
      },
      mode: 'cors',
      body: JSON.stringify(data)
    })
    document.getElementById("acc").innerHTML = "Accepted";
  }

     
  function onApprove1() 
  {
    let retailerId = 'FFR001';
    let reference = 'ubi123';
    let status ='decline';
    let data = {retailerId,reference,status};
    console.log(JSON.stringify(data));
   
    fetch('https://ebs.fastfx2.com/client/updatebalance', {
      method: 'POST',
      headers:
      {
        'Content-Type': 'application/json'
      },
      mode: 'cors',
      body: JSON.stringify(data)
    })
    document.getElementById("rej").innerHTML = "Rejected";
  }