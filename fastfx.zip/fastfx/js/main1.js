// --------------------------Prefund Balance Api Intergration-------------------------------------------
fetch('http://fastfxbackend-env-uat.ap-south-1.elasticbeanstalk.com/admin/totalbalance')
    .then(response => {
        if (!response.ok) {
            throw new Error("HTTP error " + response.status);
        }
        return response.text();
    })
    .then(text => {
        document.getElementById("pre").innerHTML = text;
    })
    .catch(error => {
        // Handle/report error
    });

// --------------------------Successful Transaction Api Intergration-------------------------------------------

fetch('http://fastfxbackend-env-uat.ap-south-1.elasticbeanstalk.com/admin/successtrans')
    .then(response => {
        if (!response.ok) {
            throw new Error("HTTP error " + response.status);
        }
        return response.text();
    })
    .then(text => {
        document.getElementById("succ").innerHTML = text;
    })
    .catch(error => {
        // Handle/report error
    });

// --------------------------Pending Transaction Api Intergration-------------------------------------------

fetch('http://fastfxbackend-env-uat.ap-south-1.elasticbeanstalk.com/admin/pendingtrans')
    .then(response => {
        if (!response.ok) {
            throw new Error("HTTP error " + response.status);
        }
        return response.text();
    })
    .then(text => {
        document.getElementById("pend").innerHTML = text;
    })
    .catch(error => {
        // Handle/report error
    });

// -------------------------Failed Transaction Api Intergration-------------------------------------------

fetch('http://fastfxbackend-env-uat.ap-south-1.elasticbeanstalk.com/admin/failedtrans')
    .then(response => {
        if (!response.ok) {
            throw new Error("HTTP error " + response.status);
        }
        return response.text();
    })
    .then(text => {
        document.getElementById("fail").innerHTML = text;
    })
    .catch(error => {
        // Handle/report error
    });
    // -------------------------Failed Transaction Api Intergration-------------------------------------------
function view(){
fetch('http://fastfxbackend-env-uat.ap-south-1.elasticbeanstalk.com/recharge/checkbalance')
.then(response => {
    if (!response.ok) {
        throw new Error("HTTP error " + response.status);
    }
    return response.text();
})
.then(text => {
    document.getElementById("merchantview").innerHTML = text;
})
.catch(error => {
    // Handle/report error
});
}


/*-------------------Download Table------------------------------*/
function exportTableToExcel(tableID, filename = '') {
    //var tableHTML = "<html><head><style> table, td {border:2px solid black}table {border-collapse:collapse}</style></head><body><table><tr>";
    var downloadLink;
    var dataType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
  
    // Specify file name
    filename = filename ? filename + '.xls' : 'data.xls';
  
    // Create download link element
    downloadLink = document.createElement("a");
  
    document.body.appendChild(downloadLink);
  
    if (navigator.msSaveOrOpenBlob) {
      var blob = new Blob(['\ufeff', tableHTML], {
        type: dataType
      });
      navigator.msSaveOrOpenBlob(blob, filename);
    } else {
      // Create a link to the file
      downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
  
      // Setting the file name
      downloadLink.download = filename;
  
      //triggering the function
      downloadLink.click();
    }
  }