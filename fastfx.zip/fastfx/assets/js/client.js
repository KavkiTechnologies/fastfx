//-------------------------Client Wallet-------------------------------//
fetch('https://ebs.fastfx2.com/client/fastxbalance/FFX001')
    .then(response => {
        if (!response.ok) {
            throw new Error("HTTP error " + response.status);
        }
        return response.text();
    })
    .then(text => {
        document.getElementById("cwallet").innerHTML = text;
    })
    .catch(error => {
        // Handle/report error
    });
//-------------------------Client Successful-------------------------------//
fetch('https://ebs.fastfx2.com/client/successtrans/FFX001')
    .then(response => {
        if (!response.ok) {
            throw new Error("HTTP error " + response.status);
        }
        return response.text();
    })
    .then(text => {
        document.getElementById("csuccess").innerHTML = text;
    })
    .catch(error => {
        // Handle/report error
    });

  