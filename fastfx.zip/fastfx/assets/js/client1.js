
  
  
 function show() {
    var table = document.getElementById("data");
    var rows = table.getElementsByTagName("tr");
    for (i = 1; i < rows.length; i++) {
        row = table.rows[i];
        row.onclick = function(){
                          var cell = this.getElementsByTagName("td")[1];
                          var retailerId = cell.innerHTML;
                          alert("retailerId" + retailerId );
                      };
    }
}
