﻿/*
* This method is used to send data to server by making ajax call.
* [mainly to save, update, delete or any other server operations as well]
* if response is empty, calling function has to handle the empty response object.
* Parameters{
strUrl = URL as string to be used for ajax call.
arrParams = Parameters to be passed to the ajax call as object array.
bIsCache = Should set cache ON as boolean value.
bIsAsync = Is an aynchronous call as boolean value.
bShowLoadPnl - Whether Page loading to be happen or not.
fnSuccess = Function reference to be called on success of the ajax cal.
fnSuccessParams = Contains parameters to pass for the Success function.
}
*/
function postData(strUrl, arrParams, bIgnoreFormat, bIsCache, bIsAsync, bShowLoadPnl, fnSuccess, fnSuccessParams) {	
    var objResponse = null;
    bIgnoreFormat = (bIgnoreFormat == null ? false : bIgnoreFormat);
    //var bIsLoading = ((bShowLoadPnl != undefined) ? bShowLoadPnl : false);
     var bIsValid = true;
   // var bIsValid = isValidSession();
   // if ($('#hdnExamStatus').val() == 'C') {
     //   bIsValid = true;
   // }
    if (!bIsValid) onUpdateStudentSessionTimeOut();
    else {
        //resetTimer();
        $.ajax({
            cache: ((bIsCache == undefined) ? false : bIsCache),
            type: 'POST',
            url: strUrl,
			timeout: 50000,
            async: ((bIsAsync == undefined) ? true : bIsAsync),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            data: arrParams,
            success: function (response) {
                //if (bIsLoading) onEndRequest();
                if (response != undefined && response != '') {
                    if (response.Header != undefined) {
                    if (bIgnoreFormat) { objResponse = response; }
                    else {
                        if (response.Header.ResponseCode == 0) {
                            notifyServerError();
                        } else if (response.Header.ResponseCode == 1) {
                            alert(response.Header.Message);
                        } else {
                                if (fnSuccess != undefined) {
                                    if (fnSuccessParams != undefined) fnSuccess(response.Body, fnSuccessParams);
                                    else fnSuccess(response.Body);
                                } else objResponse = response.Body;
                        }
                    }
                    } else objResponse = response;
                    }
            },
            error: function (message, textStatus, errorThrown) {
                //Fixed SC-9270
               console.log(message);
                //if (Offline.state == 'up') notifyServerError();
            }
        });
    }
    return objResponse;
}




