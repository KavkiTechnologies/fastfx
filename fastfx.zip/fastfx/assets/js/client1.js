  //-------------------------Client prefund approval-------------------------------//
    
  function onapprove() 
  {
    let retailerId = $('#retailerId').val();
    let reference = $('#reference').val();
    let lm = {retailerId,reference};

    var vUserData = postData('http://fastfxbackend-env.eba-ihyda3cq.ap-southeast-1.elasticbeanstalk.com/client/updatebalance', JSON.stringify(lm), false, false, false, false);

    if (vUserData.status == "accept") {
        alert("Balance Updated in retailer wallet")/*displays error message*/
    }
    else {
      alert("Request denied")/*displays error message*/
    }
  }